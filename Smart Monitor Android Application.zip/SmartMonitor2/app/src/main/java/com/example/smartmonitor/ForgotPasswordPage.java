package com.example.smartmonitor;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class ForgotPasswordPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password_page);
        EditText forgotten_email = findViewById(R.id.forgotten_email);
        EditText security_question = findViewById(R.id.q_security);
        EditText email2 = findViewById(R.id.email);
        EditText pass_w = findViewById(R.id.password);
        EditText pass_wr = findViewById(R.id.password_retype);
        EditText add_1 = findViewById(R.id.address1);
        EditText add_2 = findViewById(R.id.address2);
        EditText add_3 = findViewById(R.id.address3);
        EditText add_4 = findViewById(R.id.address4);
        Button ip_update = findViewById(R.id.ip_update);
        Button reset = findViewById(R.id.reset_password);
        EditText email_3 = findViewById(R.id.mail);
        Button Retrieve_button = findViewById(R.id.retrieve_button);
        DBHelper DB = new DBHelper(this);

        //Method to retrieve password
        Retrieve_button.setOnClickListener(view -> {
           // @Override
           // public void onClick(View v) {
                String email = forgotten_email.getText().toString();
                String answer = security_question.getText().toString();
                Boolean check_email = DB.check_email_address(email);
                Cursor get_password = DB.retrieve_password(email);
                Boolean check_if_security_answer_in_database = DB.check_security_answer(answer);
                if (email.equals("") | answer.equals("")) {
                    Toast.makeText(ForgotPasswordPage.this, "PLEASE FILL IN ALL FIELDS", Toast.LENGTH_SHORT).show();
                } else {
                    if (!check_email) {
                        Toast.makeText(ForgotPasswordPage.this, "This EMAIL WAS NEVER USED TO SIGNUP", Toast.LENGTH_LONG).show();
                    } else {
                        if (!check_if_security_answer_in_database) {
                            Toast.makeText(ForgotPasswordPage.this, "SECURITY QUESTION ANSWER IS WRONG", Toast.LENGTH_LONG).show();
                        } else {
                            if (get_password.getCount()==0){
                                Toast.makeText(ForgotPasswordPage.this, "PASSWORD FOR THIS EMAIL NONEXISTENT", Toast.LENGTH_SHORT).show();
                            }
                            else {
                                StringBuilder buffer = new StringBuilder();
                                while (get_password.moveToNext()){
                                    buffer.append(get_password.getString(0)).append("\n");
                                }
                                AlertDialog.Builder builder =new AlertDialog.Builder(ForgotPasswordPage.this);
                                builder.setCancelable(true);
                                builder.setTitle("Retrieved Password");
                                builder.setMessage(buffer.toString());
                                builder.show();
                            }
                        }
                    }
                }
            //}
        });
        // reset password
        reset.setOnClickListener(view -> {
            //@Override
            //public void onClick(View v) {
                String email_2 = email2.getText().toString();
                String password2 = pass_w.getText().toString();
                String retype_password2 = pass_wr.getText().toString();
                Boolean check_email = DB.check_email_address(email_2);
                if (email_2.equals("") | password2.equals("") | retype_password2.equals("")) {
                    Toast.makeText(ForgotPasswordPage.this, "PLEASE FILL IN ALL 3 FIELDS", Toast.LENGTH_SHORT).show();
                }
                else {
                    if (!check_email){
                        Toast.makeText(ForgotPasswordPage.this,"THIS EMAIL WAS NEVER USED TO SIGNUP",Toast.LENGTH_LONG).show();
                    }
                    else {
                        if (!password2.equals(retype_password2)){
                            Toast.makeText(ForgotPasswordPage.this,"PASSWORDS DO NOT MATCH",Toast.LENGTH_LONG).show();
                        }
                        else {
                            boolean resetting = DB.reset(email_2, password2);
                            if (resetting){
                                Toast.makeText(ForgotPasswordPage.this,"PASSWORD RESET SUCCESSFUL",Toast.LENGTH_LONG).show();
                                Intent back_to_sign_in_page1 = new Intent(getApplicationContext(),MainActivity.class);
                                startActivity(back_to_sign_in_page1);
                            }
                            else {
                                Toast.makeText(ForgotPasswordPage.this,"PASSWORD RESET UNSUCCESSFUL",Toast.LENGTH_LONG).show();
                            }
                        }
                    }

                }

             //}
        });

        // update ip addresses
        ip_update.setOnClickListener(view -> {
            String add1 = add_1.getText().toString();
            String add2 = add_2.getText().toString();
            String add3 = add_3.getText().toString();
            String add4 = add_4.getText().toString();
            String email3 = email_3.getText().toString();
            Boolean mail = DB.check_email_address(email3);
            if (!mail){
                Toast.makeText(ForgotPasswordPage.this,"THIS EMAIL WAS NEVER USED TO SIGNUP",Toast.LENGTH_LONG).show();
            }
           else {
               if (!add1.equals("")){
                   boolean reset_ip_1 = DB.reset_ip1(email3, add1);
                   if (reset_ip_1){
                       Toast.makeText(ForgotPasswordPage.this,"IP RESET SUCCESSFUL",Toast.LENGTH_LONG).show();
                   }
               }
                if (!add2.equals("")){
                    boolean reset_ip_2 = DB.reset_ip2(email3, add2);
                    if (reset_ip_2){
                        Toast.makeText(ForgotPasswordPage.this,"IP RESET SUCCESSFUL",Toast.LENGTH_LONG).show();
                    }
                }
                if (!add3.equals("")){
                    boolean reset_ip_3 = DB.reset_ip3(email3, add3);
                    if (reset_ip_3){
                        Toast.makeText(ForgotPasswordPage.this,"IP RESET SUCCESSFUL",Toast.LENGTH_LONG).show();
                    }
                }
                if (!add4.equals("")){
                    boolean reset_ip_4 = DB.reset_ip4(email3, add4);
                    if (reset_ip_4){
                        Toast.makeText(ForgotPasswordPage.this,"IP RESET SUCCESSFUL",Toast.LENGTH_LONG).show();
                    }
                }
            }
            Intent back_to_sign_in_page2 = new Intent(getApplicationContext(),MainActivity.class);
            startActivity(back_to_sign_in_page2);
        });
    }
}