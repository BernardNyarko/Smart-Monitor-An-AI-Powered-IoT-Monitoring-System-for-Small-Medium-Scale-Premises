package com.example.smartmonitor;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class SignupPage extends AppCompatActivity {
    public static final String PARSE_EMAIL2= "com.example.smart_monitor.PARSE_EMAIL";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup_page);

        //creating and declaring variables
        EditText First_name = findViewById(R.id.first_name);
        EditText Last_name = findViewById(R.id.last_name);
        EditText Email_address = findViewById(R.id.email_signup);
        EditText Password = findViewById(R.id.password_signup);
        EditText Retype_password = findViewById(R.id.retype_password_signup);
        EditText security_question = findViewById(R.id.security_question);
        EditText authentication = findViewById(R.id.authentication_code);
        Button signup = findViewById(R.id.signup);
        DBHelper DB = new DBHelper(this);

        //Button for signing up
        signup.setOnClickListener(view -> {
            //@Override
            //public void onClick(View v) {
                String first_name = First_name.getText().toString();
                String last_name = Last_name.getText().toString();
                String email = Email_address.getText().toString();
                String pass_word = Password.getText().toString();
                String re_password = Retype_password.getText().toString();
                String s_question = security_question.getText().toString();
                String authenticate = authentication.getText().toString();
                String Address_1 = "";
                String Address_2 = "";
                String Address_3 = "";
                String Address_4 = "";


                if (first_name.equals("")) {
                    First_name.setError("First Name is required");
                    First_name.requestFocus();
                    return;
                }
                if (last_name.isEmpty()){
                    Last_name.setError("Last name is required");
                    Last_name.requestFocus();
                    return;
                }
                if (email.isEmpty() | !Patterns.EMAIL_ADDRESS.matcher(email).matches()){
                    Email_address.setError("Please provide a valid email");
                    Email_address.requestFocus();
                    return;
                }

                if (pass_word.length() < 7 | pass_word.isEmpty()){
                    Password.setError("Password length less than 7");
                    Password.requestFocus();
                    return;
                }
                if (re_password.length() < 7 | re_password.isEmpty()){
                    Retype_password.setError("Retyped password length less than 7");
                    Retype_password.requestFocus();
                    return;
                }
                if (s_question.isEmpty()){
                    security_question.setError("Provide answer");
                    security_question.requestFocus();
                    return;
                }
                if (authenticate.isEmpty()) {
                    authentication.setError("Enter authentication code");
                    authentication.requestFocus();
                    return;
                }

                if (pass_word.equals(re_password) && pass_word.length() >= 6 && (authenticate.equals("Bernard") | authenticate.equals("1234"))) {
                    Boolean check_email = DB.check_email_address(email);
                    if (!check_email) {
                        Boolean insert = DB.insertData(first_name, last_name, email, pass_word, s_question, Address_1, Address_2, Address_3, Address_4);
                        if (insert) {
                            Toast.makeText(SignupPage.this, "SIGNUP SUCCESSFUL", Toast.LENGTH_SHORT).show();
                            Intent insert_ip = new Intent(getApplicationContext(), Camera1.class);
                            insert_ip.putExtra(PARSE_EMAIL2,email);
                            startActivity(insert_ip);
                        } else {
                            Toast.makeText(SignupPage.this, "SIGNUP UNSUCCESSFUL!! TRY AGAIN", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(SignupPage.this, "USER ALREADY EXIST", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(SignupPage.this, "PASSWORDS DO NOT MATCH", Toast.LENGTH_SHORT).show();
                }
        });

    }
}