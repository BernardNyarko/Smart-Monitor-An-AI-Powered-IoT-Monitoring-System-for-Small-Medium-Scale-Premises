package com.example.smartmonitor;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Camera1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_camera1);
        EditText address_1 = findViewById(R.id.address1);
        EditText address_2 = findViewById(R.id.address2);
        EditText address_3 = findViewById(R.id.address3);
        EditText address_4 = findViewById(R.id.address4);
        Button save_ip = findViewById(R.id.ip_save);
        DBHelper DB = new DBHelper(this);
        Intent retrieve_intent = getIntent();
        String email = retrieve_intent.getStringExtra(SignupPage.PARSE_EMAIL2);

        // button to set ip addresses
        save_ip.setOnClickListener(v -> {
            String ip1 = address_1.getText().toString();
            String ip2 = address_2.getText().toString();
            String ip3 = address_3.getText().toString();
            String ip4 = address_4.getText().toString();
            if (!ip1.equals("")){
                boolean reset_ip_1 = DB.reset_ip1(email, ip1);
                if (!reset_ip_1){
                    Toast.makeText(Camera1.this,"Could not insert ip",Toast.LENGTH_LONG).show();
                }
            }
            if (!ip2.equals("")){
                boolean reset_ip_1 = DB.reset_ip2(email, ip2);
                if (!reset_ip_1){
                    Toast.makeText(Camera1.this,"Could not insert ip",Toast.LENGTH_LONG).show();
                }
            }
            if (!ip3.equals("")){
                boolean reset_ip_1 = DB.reset_ip3(email, ip3);
                if (!reset_ip_1){
                    Toast.makeText(Camera1.this,"Could not insert ip",Toast.LENGTH_LONG).show();
                }
            }
            if (!ip4.equals("")){
                boolean reset_ip_1 = DB.reset_ip4(email, ip4);
                if (!reset_ip_1){
                    Toast.makeText(Camera1.this,"Could not insert ip",Toast.LENGTH_LONG).show();
                }
            }
            Intent back_to_sign_in_page2 = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(back_to_sign_in_page2);
        });

    }
}