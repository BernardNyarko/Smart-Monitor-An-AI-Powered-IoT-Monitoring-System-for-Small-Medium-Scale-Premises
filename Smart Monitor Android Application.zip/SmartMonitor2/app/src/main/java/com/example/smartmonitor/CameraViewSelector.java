package com.example.smartmonitor;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.net.http.SslError;
import android.os.Bundle;
import android.view.KeyEvent;
import android.webkit.SslErrorHandler;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;


public class CameraViewSelector extends AppCompatActivity {

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_camera_view_selector);
        Intent retrieve_intent = getIntent();
        String email = retrieve_intent.getStringExtra(MainActivity.PARSE_EMAIL);
        WebView web1 = findViewById(R.id.webView1);
        WebView web2 = findViewById(R.id.webView2);
        WebView web3 = findViewById(R.id.webView3);
        WebView web4 = findViewById(R.id.webView4);
        Button logout = findViewById(R.id.logout);
        DBHelper DB = new DBHelper(this);

        Cursor get_ip1 = DB.retrieve_ip_1(email);
        if (get_ip1.getCount()>=0){
            StringBuilder cam_1= new StringBuilder();
            while (get_ip1.moveToNext()){
                cam_1.append(get_ip1.getString(0)).append("\n");
            }
            String url1 = cam_1.toString();
            WebSettings webSettings = web1.getSettings();
            webSettings.setJavaScriptEnabled(true);
            web1.setWebViewClient(new CameraViewSelector.MyClientWebView());
            web1.loadUrl(url1);
        }

        Cursor get_ip2 = DB.retrieve_ip_2(email);
        if (get_ip2.getCount()>=1) {
            StringBuilder cam_2 = new StringBuilder();
            while (get_ip2.moveToNext()){
                cam_2.append(get_ip2.getString(0)).append("\n");
            }
            String url2 = cam_2.toString();
            WebSettings webSettings2 = web2.getSettings();
            webSettings2.setJavaScriptEnabled(true);
            web2.setWebViewClient(new CameraViewSelector.MyClientWebView2());
            web2.loadUrl(url2);
        }
        Cursor get_ip3 = DB.retrieve_ip_3(email);
        if (get_ip3.getCount()>=1) {
            StringBuilder cam_3 = new StringBuilder();
            while (get_ip3.moveToNext()) {
                cam_3.append(get_ip3.getString(0)).append("\n");
            }
            String url3 = cam_3.toString();
            WebSettings webSettings3 = web3.getSettings();
            webSettings3.setJavaScriptEnabled(true);
            web3.setWebViewClient(new CameraViewSelector.MyClientWebView3());
            web3.loadUrl(url3);
        }
        Cursor get_ip4 = DB.retrieve_ip_4(email);
        if (get_ip4.getCount()>=1) {
            StringBuilder cam_4 = new StringBuilder();
            while (get_ip4.moveToNext()) {
                cam_4.append(get_ip4.getString(0)).append("\n");
            }
            String url4 = cam_4.toString();

            WebSettings webSettings4 = web4.getSettings();
            webSettings4.setJavaScriptEnabled(true);
            web4.setWebViewClient(new CameraViewSelector.MyClientWebView4());
            web4.loadUrl(url4);
        }

        logout.setOnClickListener(v -> {
            AlertDialog.Builder builder2 = new AlertDialog.Builder(CameraViewSelector.this);
            builder2.setMessage("Do you want to logout?");
            builder2.setPositiveButton("Yes", (dialog, which) -> {
                finish();
                Intent logout1 = new Intent();
                logout1.putExtra("finish", true);
                logout1.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                finish();
            });
            builder2.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());
            AlertDialog logout_alert = builder2.create();
            logout_alert.show();
        });

    }


    private class MyClientWebView extends WebViewClient {
        @Override
        public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
            final AlertDialog.Builder builder = new AlertDialog.Builder(CameraViewSelector.this);
            builder.setMessage("SSL Error! Give Permission");
            builder.setPositiveButton("continue", (dialog, which) -> handler.cancel());
            builder.setNegativeButton("cancel", (dialog, which) -> handler.cancel());
            final AlertDialog dialog = builder.create();
            dialog.show();
        }

        @Override
        public boolean shouldOverrideKeyEvent(WebView view, KeyEvent event) {
            return false;
        }
    }

    private class MyClientWebView2 extends WebViewClient {
        @Override
        public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
            final AlertDialog.Builder builder1= new AlertDialog.Builder(CameraViewSelector.this);
            builder1.setMessage("SSL Error! Give Permission");
            builder1.setPositiveButton("continue", (dialog, which) -> handler.cancel());
            builder1.setNegativeButton("cancel", (dialog, which) -> handler.cancel());
            final AlertDialog dialog2 = builder1.create();
            dialog2.show();
        }

        @Override
        public boolean shouldOverrideKeyEvent(WebView view, KeyEvent event) {
            return false;
        }
    }

    private class MyClientWebView3 extends WebViewClient {
        @Override
        public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
            final AlertDialog.Builder builder3 = new AlertDialog.Builder(CameraViewSelector.this);
            builder3.setMessage("SSL Error! Give Permission");
            builder3.setPositiveButton("continue", (dialog, which) -> handler.cancel());
            builder3.setNegativeButton("cancel", (dialog, which) -> handler.cancel());
            final AlertDialog dialog3 = builder3.create();
            dialog3.show();
        }

        @Override
        public boolean shouldOverrideKeyEvent(WebView view, KeyEvent event) { return false; }
    }
    private class MyClientWebView4 extends WebViewClient {
        @Override
        public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
            final AlertDialog.Builder builder4 = new AlertDialog.Builder(CameraViewSelector.this);
            builder4.setMessage("SSL Error! Give Permission");
            builder4.setPositiveButton("continue", (dialog, which) -> handler.cancel());
            builder4.setNegativeButton("cancel", (dialog, which) -> handler.cancel());
            final AlertDialog dialog4 = builder4.create();
            dialog4.show();
        }

        @Override
        public boolean shouldOverrideKeyEvent(WebView view, KeyEvent event) {
            return false;
        }
    }
}