package com.example.smartmonitor;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Patterns;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;



public class MainActivity extends AppCompatActivity {
    public static final String PARSE_EMAIL= "com.example.smart_monitor.PARSE_EMAIL";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Creating and declaring variables
        EditText email_address = findViewById(R.id.email_address);
        EditText password = findViewById(R.id.password);
        TextView forgot_password = findViewById(R.id.forget);
        Button login_button = findViewById(R.id.login_button);
        Button signup_button = findViewById(R.id.sign_up_button);
        FloatingActionButton twitter = findViewById(R.id.twitter_id);
        FloatingActionButton google = findViewById(R.id.google_id);
        FloatingActionButton facebook = findViewById(R.id.facebook_id);
        FloatingActionButton youtube = findViewById(R.id.youtube_id);
        FloatingActionButton linkedin = findViewById(R.id.linkedin_id);
        DBHelper DB = new DBHelper(this);

        
        //Button Click to login
        login_button.setOnClickListener(view -> {
          //  @Override
           // public void onClick(View v) {
                String email = email_address.getText().toString();
                String p_word = password.getText().toString();
                if (email.isEmpty() | !Patterns.EMAIL_ADDRESS.matcher(email).matches()){
                    email_address.setError("Please provide valid email");
                    email_address.requestFocus();
                    return;
                }
                if (p_word.isEmpty()){
                    password.setError("Password is required");
                }
                else {
                    Boolean check_email_pass = DB.check_email_password(email, p_word);
                    if (check_email_pass ){
                        Toast.makeText(MainActivity.this, "SIGN IN SUCCESSFUL",Toast.LENGTH_SHORT).show();
                        Intent Video_Stream_Page_Intent = new Intent(getApplicationContext(),CameraViewSelector.class);
                        Video_Stream_Page_Intent.putExtra(PARSE_EMAIL, email);
                        startActivity(Video_Stream_Page_Intent);
                        email_address.setText("");
                        password.setText("");

                    }
                    else {
                        Toast.makeText(MainActivity.this, "INVALID CREDENTIALS", Toast.LENGTH_SHORT).show();
                    }
                }
            //}
        });

        //Button Click to Transfer from MainActivity to SignUpPage activity
        signup_button.setOnClickListener(view -> {
            //@Override
           // public void onClick(View v) {
                Intent signup_page_intent = new Intent(MainActivity.this,SignupPage.class);
                startActivity(signup_page_intent);
           // }
        });
        //Button click to transfer MainActivity to ForgetPasswordPage
        forgot_password.setOnClickListener(view -> {
           // @Override
            //public void onClick(View v) {
                Intent forgot_password_intent = new Intent(MainActivity.this,ForgotPasswordPage.class);
                startActivity(forgot_password_intent);

            //}
        });


        // Button to open twitter homepage
        twitter.setOnClickListener(view -> {
            //@Override
            //public void onClick(View v) {
                Intent twitter_intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.twitter.com"));
                startActivity(twitter_intent);
            //}
        });

        //Button to open Google homepage
        google.setOnClickListener(view -> {
            //@Override
            //public void onClick(View v) {
                Intent google_intent = new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.google.com"));
                startActivity(google_intent);
            //}
        });

        //Button to open facebook homepage
        facebook.setOnClickListener(view -> {
            //@Override
            //public void onClick(View v) {
                Intent facebook_intent = new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.facebook.com"));
                startActivity(facebook_intent);
            //}
        });

        //Button to open youtube homepage
        youtube.setOnClickListener(view -> {
            //@Override
            //public void onClick(View v) {
                Intent youtube_intent = new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.youtube.com"));
                startActivity(youtube_intent);
            //}
        });

        //Button to open LinkedIn homepage
        linkedin.setOnClickListener(view -> {
            //@Override
            //public void onClick(View v) {
                Intent linkedin_intent = new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.linkedin.com"));
                startActivity(linkedin_intent);
            //}
        });

    }
}