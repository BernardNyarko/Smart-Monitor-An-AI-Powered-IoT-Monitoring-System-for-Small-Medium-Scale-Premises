package com.example.smartmonitor;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;



public class DBHelper extends SQLiteOpenHelper{
    //creating a variable name for database
    public static final String database_name = "smart_monitor_db";


    //creating the database smart_monitor_db
    public DBHelper(Context context) {
        super(context, database_name, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase MyDB) {
        //query to create database table named emails
        MyDB.execSQL("create Table emails(first_name TEXT, last_name TEXT, email_address TEXT primary key, " +
                "password TEXT, security_answer TEXT, IP_1 TEXT, IP_2 TEXT, IP_3 TEXT, IP_4 TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase MyDB, int  oldVersion, int newVersion) {
        //query to drop database table created above if it exists
        MyDB.execSQL("drop Table if exists emails");
    }
    public Boolean insertData(String f_name, String l_name, String email_address, String password, String s_question, String IP_1,
                              String IP_2, String IP_3, String IP_4 ){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("first_name", f_name);
        contentValues.put("last_name",l_name);
        contentValues.put("email_address", email_address);
        contentValues.put("password", password);
        contentValues.put("security_answer", s_question);
        contentValues.put("IP_1", IP_1);
        contentValues.put("IP_2", IP_2);
        contentValues.put("IP_3", IP_3);
        contentValues.put("IP_4", IP_4);

        long result = MyDB.insert("emails", null, contentValues);
        // If insertion is not possible (-1 indicates failure)
        // If insertion is possible
        return result != -1;
    }
    public boolean reset(String email_address, String password){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("password", password);
        long resetting = MyDB.update("emails", contentValues, "email_address = ?",new String[] {email_address});
        return resetting != -1;
    }
    public boolean reset_ip1(String email_address, String add1){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("IP_1", add1);
        long resetting2 = MyDB.update("emails", contentValues, "email_address = ?",new String[] {email_address});
        return resetting2 != -1;
    }
    public boolean reset_ip2(String email_address, String add2){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("IP_2", add2);
        long resetting3 = MyDB.update("emails", contentValues, "email_address = ?",new String[] {email_address});
        return resetting3 != -1;
    }
    public boolean reset_ip3(String email_address, String add3){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("IP_3", add3);
        long resetting4 = MyDB.update("emails", contentValues, "email_address = ?",new String[] {email_address});
        return resetting4 != -1;
    }
    public boolean reset_ip4(String email_address, String add4){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("IP_4", add4);
        long resetting5 = MyDB.update("emails", contentValues, "email_address = ?",new String[] {email_address});
        return resetting5 != -1;
    }
    //function to check if email address exist
    public Boolean check_email_address(String email_address){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor1 = MyDB.rawQuery("Select * from emails where email_address = ?", new String [] {email_address});
        if (cursor1.getCount() > 0) {
            cursor1.close();
            return true;
        }
        else {
            cursor1.close();
            return false;
        }
    }
    public Boolean check_email_password(String email_address, String password){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor2 = MyDB.rawQuery("Select * from emails where email_address = ? and password = ?",
                new String[] {email_address, password});
        if (cursor2.getCount() > 0) {
            cursor2.close();
            return true;
        }
        else {
            cursor2.close();
            return false;
        }

    }
    public Boolean check_security_answer( String security_answer){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor3 = MyDB.rawQuery("Select * from emails where security_answer = ?", new String[] {security_answer});
        if (cursor3.getCount() > 0) {
            cursor3.close();
            return true;
        }
        else {
            cursor3.close();
            return false;
        }

    }
    public Cursor retrieve_password(String email_address){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        return MyDB.rawQuery("Select password from emails where email_address = ?", new String[] {email_address});
    }
    public Cursor retrieve_ip_1(String email_address){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        return MyDB.rawQuery("Select IP_1 from emails where email_address = ?", new String[] {email_address});
    }
    public Cursor retrieve_ip_2(String email_address){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        return MyDB.rawQuery("Select IP_2 from emails where email_address = ?", new String[] {email_address});
    }
    public Cursor retrieve_ip_3(String email_address){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        return MyDB.rawQuery("Select IP_3 from emails where email_address = ?", new String[] {email_address});
    }
    public Cursor retrieve_ip_4(String email_address){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        return MyDB.rawQuery("Select IP_4 from emails where email_address = ?", new String[] {email_address});
    }
}
